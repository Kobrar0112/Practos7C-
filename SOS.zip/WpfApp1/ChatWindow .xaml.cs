﻿using System;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    public partial class ChatWindow : Window
    {
        private TcpClient _tcpClient;
        private string _userName;
        private string _ipAddress;

        public ChatWindow(TcpClient tcpClient, string userName, string ipAddress)
        {
            InitializeComponent();
            _tcpClient = tcpClient;
            _userName = userName;
            _ipAddress = ipAddress;

            _tcpClient.MessageReceived += TcpClient_MessageReceived;
            SendMessageButton.Click += SendMessageButton_Click;
            DisconnectButton.Click += DisconnectButton_Click;

            if (_userName == "Admin")
            {
                _tcpClient.ConnectionChanged += TcpClient_ConnectionChanged;
                AdminLogListBox.Visibility = Visibility.Visible;
            }
            else
            {
                AdminLogListBox.Visibility = Visibility.Collapsed;
            }

            Task.Run(ConnectToServer);
        }

        private void TcpClient_ConnectionChanged(object sender, string message)
        {
            Dispatcher.Invoke(() =>
            {
                AdminLogListBox.Items.Add($"[{DateTime.Now.ToString("HH:mm:ss")}] {message}");
                AdminLogListBox.Items.Refresh();
                AdminLogListBox.ScrollIntoView(AdminLogListBox.Items[AdminLogListBox.Items.Count - 1]);
            });
        }

        private async Task ConnectToServer()
        {
            try
            {
                await _tcpClient.ConnectAsync(_ipAddress, 12345);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось подключиться к серверу: " + ex.Message);
                this.Close();
            }
        }

        private async void SendMessageButton_Click(object sender, RoutedEventArgs e)
        {
            string message = MessageTextBox.Text;
            if (!string.IsNullOrEmpty(message))
            {
                await _tcpClient.SendMessageAsync(_userName + ": " + message);
                MessageTextBox.Text = string.Empty;
            }
        }

        private void DisconnectButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();

        }

        private void TcpClient_MessageReceived(object sender, string message)
        {
            AddMessage(message);
        }

        public void AddMessage(string message)
        {
            Dispatcher.Invoke(() =>
            {
                ChatListBox.Items.Add($"[{DateTime.Now.ToString("HH:mm:ss")}] {message}");
                ChatListBox.Items.Refresh();
                ChatListBox.ScrollIntoView(ChatListBox.Items[ChatListBox.Items.Count - 1]);
            });
        }
    }
}