﻿using System.Windows;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CreateNewChat_Click(object sender, RoutedEventArgs e)
        {
            string userName = UserNameTextBox.Text;
            string ipAddress = IPTextBox.Text;

            if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(ipAddress))
            {
                MessageBox.Show("Пожалуйста, введите имя пользователя и IP-адрес.");
                return;
            }

            TcpClient tcpClient = new TcpClient();
            ChatWindow chatWindow = new ChatWindow(tcpClient, userName, ipAddress);
            chatWindow.Title = "Новый чат";
            chatWindow.Show();
            this.Close();
        }

        private void ConnectToExistingChat_Click(object sender, RoutedEventArgs e)
        {
            string userName = UserNameTextBox.Text;
            string ipAddress = IPTextBox.Text;

            if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(ipAddress))
            {
                MessageBox.Show("Пожалуйста, введите имя пользователя и IP-адрес.");
                return;
            }

            TcpClient tcpClient = new TcpClient();
            ChatWindow chatWindow = new ChatWindow(tcpClient, userName, ipAddress);
            chatWindow.Title = "Существующий чат";
            chatWindow.Show();
            this.Close();
        }
    }
}