﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private TcpServer _server;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            _server = new TcpServer();
            _server.StartServerAsync(12345);
        }
    }
}
